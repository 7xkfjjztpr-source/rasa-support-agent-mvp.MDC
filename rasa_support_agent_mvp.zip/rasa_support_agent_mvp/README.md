# Rasa Support Agent MVP (FR/EN)

## Prérequis
- Python 3.9 ou 3.10 recommandé
- pip, venv

## Installation
```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS/Linux
source .venv/bin/activate

pip install --upgrade pip
pip install rasa==3.6.* rasa-sdk==3.6.*
```

## Démarrage
```bash
rasa train
rasa shell
```
*Optionnel (actions serveur)*
```bash
rasa run actions
```

## Structure
- config.yml : pipeline NLU et policies
- domain.yml : intents/réponses
- data/nlu.yml : exemples d'entraînement
- data/rules.yml, data/stories.yml : règles et scénarios
- endpoints.yml : configuration du serveur d'actions
- actions/actions.py : actions personnalisées (facultatif au début)
