# actions/actions.py
# Pour un MVP sans logique serveur, vous pouvez laisser vide ou ajouter des actions plus tard.
# Exemple de squelette si besoin :
from typing import Any, Text, Dict, List
from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher

class ActionHello(Action):
    def name(self) -> Text:
        return "action_hello"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        dispatcher.utter_message(text="Salut, action serveur en place.")
        return []
